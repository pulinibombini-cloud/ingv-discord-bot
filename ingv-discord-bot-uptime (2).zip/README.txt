INGV Discord Bot
================

Avvio:
  npm install
  npm start

Variabili d'ambiente richieste:
  DISCORD_BOT_TOKEN  -> token del bot Discord
  DISCORD_CHANNEL_ID -> ID del canale Discord dove pubblicare i terremoti

Richiede Node.js 18 o superiore.
