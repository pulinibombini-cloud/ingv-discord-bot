import { Client, GatewayIntentBits, EmbedBuilder } from "discord.js";
import http from "node:http";

const TOKEN = process.env.DISCORD_BOT_TOKEN;
const CHANNEL_ID = process.env.DISCORD_CHANNEL_ID;
const PORT = Number(process.env.PORT) || 3000;
const POLL_INTERVAL_MS = 30_000;
const INGV_BASE = "https://webservices.ingv.it/fdsnws/event/1/query";

if (!TOKEN) {
  console.error("Missing DISCORD_BOT_TOKEN");
  process.exit(1);
}
if (!CHANNEL_ID) {
  console.error("Missing DISCORD_CHANNEL_ID");
  process.exit(1);
}

let botStatus = "starting";
let lastPostedAt = null;
let totalPosted = 0;

http
  .createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(
      JSON.stringify({
        status: botStatus,
        lastPostedAt,
        totalPosted,
        uptimeSeconds: Math.floor(process.uptime()),
      }),
    );
  })
  .listen(PORT, () => {
    console.log(`Keepalive HTTP server in ascolto su porta ${PORT}`);
  });

const seenEventIds = new Set();
let lastSeenTime = null;

function magnitudeColor(mag) {
  if (mag >= 5) return 0xff0000;
  if (mag >= 4) return 0xff6600;
  if (mag >= 3) return 0xffaa00;
  if (mag >= 2) return 0xffee00;
  return 0x66cc66;
}

function magnitudeEmoji(mag) {
  if (mag >= 5) return "🔴";
  if (mag >= 4) return "🟠";
  if (mag >= 3) return "🟡";
  if (mag >= 2) return "🟢";
  return "⚪";
}

async function fetchLatestEarthquakes() {
  const params = new URLSearchParams({
    format: "geojson",
    limit: "20",
    orderby: "time",
  });
  if (lastSeenTime) {
    params.set("starttime", new Date(lastSeenTime.getTime() + 1000).toISOString());
  }
  const url = `${INGV_BASE}?${params.toString()}`;
  const res = await fetch(url, {
    headers: { Accept: "application/json", "User-Agent": "ingv-discord-bot/1.0" },
  });
  if (res.status === 204) return [];
  if (!res.ok) throw new Error(`INGV ${res.status} ${res.statusText}`);
  const data = await res.json();
  return data.features ?? [];
}

function buildEmbed(f) {
  const p = f.properties;
  const [lon, lat, depthKm] = f.geometry.coordinates;
  const mag = p.mag ?? 0;
  const magType = p.magType ?? "M";
  const place = p.place ?? "Località sconosciuta";
  const time = new Date(p.time);
  const unix = Math.floor(time.getTime() / 1000);
  const eventId = String(p.eventId ?? f.id);
  const ingvUrl = `https://terremoti.ingv.it/event/${eventId}`;
  const mapsUrl = `https://www.google.com/maps?q=${lat},${lon}`;

  return new EmbedBuilder()
    .setColor(magnitudeColor(mag))
    .setTitle(`${magnitudeEmoji(mag)} ${magType} ${mag.toFixed(1)} — ${place}`)
    .setURL(ingvUrl)
    .addFields(
      { name: "Orario", value: `<t:${unix}:F> (<t:${unix}:R>)`, inline: false },
      { name: "Magnitudo", value: `${magType} ${mag.toFixed(1)}`, inline: true },
      { name: "Profondità", value: `${depthKm.toFixed(1)} km`, inline: true },
      { name: "Coordinate", value: `[${lat.toFixed(3)}, ${lon.toFixed(3)}](${mapsUrl})`, inline: true },
    )
    .setFooter({ text: `INGV • Evento #${eventId}` })
    .setTimestamp(time);
}

async function poll(channel) {
  try {
    const features = await fetchLatestEarthquakes();
    if (features.length === 0) return;
    features.sort((a, b) => new Date(a.properties.time) - new Date(b.properties.time));
    for (const f of features) {
      const id = String(f.properties.eventId ?? f.id);
      if (seenEventIds.has(id)) continue;
      seenEventIds.add(id);
      const t = new Date(f.properties.time);
      if (!lastSeenTime || t > lastSeenTime) lastSeenTime = t;
      await channel.send({ embeds: [buildEmbed(f)] });
      lastPostedAt = new Date().toISOString();
      totalPosted += 1;
      console.log(`Posted ${id}: M${f.properties.mag} @ ${f.properties.place ?? "?"}`);
    }
    if (seenEventIds.size > 1000) {
      const arr = Array.from(seenEventIds);
      seenEventIds.clear();
      for (const id of arr.slice(-500)) seenEventIds.add(id);
    }
  } catch (err) {
    console.error("Poll error:", err);
  }
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once("clientReady", async () => {
  console.log(`Logged in as ${client.user?.tag}`);
  const channel = await client.channels.fetch(CHANNEL_ID);
  if (!channel || !channel.isTextBased() || !("send" in channel)) {
    console.error(`Channel ${CHANNEL_ID} non accessibile`);
    process.exit(1);
  }
  try {
    const initial = await fetchLatestEarthquakes();
    for (const f of initial) {
      seenEventIds.add(String(f.properties.eventId ?? f.id));
      const t = new Date(f.properties.time);
      if (!lastSeenTime || t > lastSeenTime) lastSeenTime = t;
    }
    const startupEmbed = new EmbedBuilder()
      .setColor(0x2ecc71)
      .setTitle("🌍 Monitoraggio terremoti INGV attivo")
      .setDescription(
        `Controllo l'API INGV ogni **${POLL_INTERVAL_MS / 1000} secondi** e pubblico qui ogni nuovo evento sismico in tempo reale.`,
      )
      .addFields(
        { name: "Fonte", value: "[INGV — Istituto Nazionale di Geofisica e Vulcanologia](https://terremoti.ingv.it)", inline: false },
        { name: "Intervallo", value: `${POLL_INTERVAL_MS / 1000}s`, inline: true },
        { name: "Eventi iniziali ignorati", value: String(initial.length), inline: true },
      )
      .setFooter({ text: "Bot avviato" })
      .setTimestamp(new Date());
    await channel.send({ embeds: [startupEmbed] });
    botStatus = "online";
    console.log(`Bot pronto. Polling ogni ${POLL_INTERVAL_MS / 1000}s.`);
  } catch (err) {
    console.error("Initial fetch failed:", err);
  }
  setInterval(() => void poll(channel), POLL_INTERVAL_MS);
});

client.on("error", (e) => console.error("Client error:", e));
client.login(TOKEN).catch((err) => {
  console.error("Login failed:", err);
  process.exit(1);
});
